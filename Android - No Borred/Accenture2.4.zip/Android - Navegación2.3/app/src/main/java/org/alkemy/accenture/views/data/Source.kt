package org.alkemy.accenture.views.data

enum class Source {
    LOCAL, REMOTE
}