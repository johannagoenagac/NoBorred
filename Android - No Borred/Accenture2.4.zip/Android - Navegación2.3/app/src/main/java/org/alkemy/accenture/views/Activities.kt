package org.alkemy.accenture.views

class Activities (
    val name: String
    )