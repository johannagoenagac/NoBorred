package org.alkemy.accenture.views.data

class RepositoryError (
    val message: String,
    val code: Int,
    val source: Source
)