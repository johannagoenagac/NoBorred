package org.alkemy.accenture.views

object Utils {

    const val participantsLabel : String = "participants"
    const val typeLabel : String = "type"
}