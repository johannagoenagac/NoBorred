package org.alkemy.accenture.views.data

class RepositoryResponse<T> (
    val data: T,
    val source: Source
)