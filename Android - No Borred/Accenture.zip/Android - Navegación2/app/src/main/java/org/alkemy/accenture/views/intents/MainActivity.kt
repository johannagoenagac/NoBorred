package org.alkemy.accenture.views.intents

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import org.alkemy.accenture.databinding.MainActivityBinding
import android.content.Intent

class MainActivity : AppCompatActivity() {

    private lateinit var binding: MainActivityBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = MainActivityBinding.inflate(layoutInflater)
        setContentView(binding.root)


        binding.buttonActivityStart.setOnClickListener {
            val intent = Intent(this, ActActivity::class.java)
            startActivity(intent)
        }

        binding.textViewTyc.setOnClickListener {
            val intent = Intent(this, TYCActivity::class.java)
            startActivity(intent)
        }
    }




}
