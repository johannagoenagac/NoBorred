package org.alkemy.accenture.views.sharedpreferences

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData

class ContadorViewModel(application: Application) : AndroidViewModel(application) {

    val valor: MutableLiveData<Int> = MutableLiveData()

    init {
        valor.value = 0
    }

    fun increment() {
        val nuevoValor = valor.value?.plus(1) ?: 1
        valor.value = nuevoValor
    }


}