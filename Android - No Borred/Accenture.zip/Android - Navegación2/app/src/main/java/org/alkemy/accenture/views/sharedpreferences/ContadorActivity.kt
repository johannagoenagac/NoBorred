package org.alkemy.accenture.views.sharedpreferences

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import org.alkemy.accenture.databinding.ContadorActivityBinding

class ContadorActivity : AppCompatActivity() {

    private val viewModel: ContadorViewModel by viewModels()

    private lateinit var binding: ContadorActivityBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ContadorActivityBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel.valor.observe(this) { value ->
            binding.contador.text = value.toString()
        }

        binding.button.setOnClickListener {
            viewModel.increment()
        }
    }

}