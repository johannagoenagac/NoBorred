package org.alkemy.accenture.views.intents

import android.os.Bundle
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import org.alkemy.accenture.R
import org.alkemy.accenture.databinding.ActActivityBinding

class ActActivity: AppCompatActivity() {

    private lateinit var binding: ActActivityBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActActivityBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val education = findViewById<EditText>(R.id.Education);
        education.setEnabled(false);
    }

}