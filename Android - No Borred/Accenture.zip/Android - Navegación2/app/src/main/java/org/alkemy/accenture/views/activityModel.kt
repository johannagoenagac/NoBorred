package org.alkemy.accenture.views

import com.google.gson.annotations.SerializedName

data class Post(
    @SerializedName("activity")
    val activity: String,
    @SerializedName("type")
    val type: String,
    @SerializedName("participants")
    val participants: Int,
    @SerializedName("price")
    val userId: Float
)